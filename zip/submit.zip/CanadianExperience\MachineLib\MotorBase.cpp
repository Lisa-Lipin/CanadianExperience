/**
 * \file MotorBase.cpp
 *
 * \author Elizabeth Lipin
 */
#include "pch.h"
#include "MotorBase.h"

/**constructor*/
CMotorBase::CMotorBase()
{
}

