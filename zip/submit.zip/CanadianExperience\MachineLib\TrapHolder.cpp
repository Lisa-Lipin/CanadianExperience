
/**
 * \file TrapHolder.cpp
 *
 * \author Elizabeth Lipin
 */#include "pch.h"
#include "TrapHolder.h"
/**constructor*/
CTrapHolder::CTrapHolder()
{
}
/**destructor*/
CTrapHolder::~CTrapHolder()
{
}
